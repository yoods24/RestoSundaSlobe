import Header from "./components/Header.tsx";
import Card from "./components/Card.tsx";
import Content from "./components/Content.tsx";
import "./App.css";
import Menudata from "./Menudata.tsx";
//import { useState } from "react";
import CardData from "./Card-data.tsx";

export default function App() {
  const dataMhs = CardData.data.map((item) => {
    return <Card {...item} />;
  });

  const food = Menudata.makanan.map((menu) => {
    return <Content {...menu} />;
  });
  console.log(food);
  return (
    <>
      <Header />
      <div className="kontener">
        <h2>Kelompok 2 RPLBK</h2>
        <h3>Daftar Kelompok</h3>
        <div className="br"></div>
        {dataMhs}
        <p className="hov">
          <span className="arrow-top">&#8605;</span>
        </p>
      </div>
      <main className="main">
        <div className="banner">
          <button className="dive-in-btn">Beli</button>
        </div>
        {food}
      </main>
    </>
  );
}
