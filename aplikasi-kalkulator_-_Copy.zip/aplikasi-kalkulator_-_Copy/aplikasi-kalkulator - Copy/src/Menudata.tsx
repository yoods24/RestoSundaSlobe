export default {
  makanan: [
    {
      id: "1",
      url: "https://d1vbn70lmn1nqe.cloudfront.net/prod/wp-content/uploads/2023/07/13073811/Praktis-dengan-Bahan-Sederhana-Ini-Resep-Nasi-Goreng-Special-1.jpg",
      price: 30000,
      menuItem: "Base",
      title:
        "nasi goreng spesial dengan hidangan sei sapi dari yordania dan dilengkapi saus barbeque",
      name: "Nasi goreng spesial",
      rating: 4.6,
    },

    {
      id: "2",
      url: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSHo2K33xzlhEs-Dg5857FBjbGgF_B7oqUZBQ&s",
      menuItem: "Base",
      price: 15000,

      name: "Karedok",
    },

    {
      id: "3",
      price: 30000,
      url: "https://awsimages.detik.net.id/community/media/visual/2022/04/20/resep-gurame-bakar-bumbu-kecap-cabe.jpeg?w=1200",
      menuItem: "Base",

      name: "Gurame Bakar",
    },

    {
      id: "4",

      menuItem: "Base",

      name: "Udon Noodles",
    },

    {
      id: "5",

      menuItem: "Base",

      name: "Jasmine Rice",
    },

    {
      id: "6",

      menuItem: "Base",

      name: "Whole-grain Rice",
    },
  ],
  minuman: [
    {
      id: "1",

      menuItem: "Base",

      name: "Egg Noodles",
    },

    {
      id: "2",

      menuItem: "Base",

      name: "Whole-wheat Noodles",
    },

    {
      id: "3",

      menuItem: "Base",

      name: "Rice Noodles",
    },

    {
      id: "4",

      menuItem: "Base",

      name: "Udon Noodles",
    },

    {
      id: "5",

      menuItem: "Base",

      name: "Jasmine Rice",
    },

    {
      id: "6",

      menuItem: "Base",

      name: "Whole-grain Rice",
    },
  ],
};
