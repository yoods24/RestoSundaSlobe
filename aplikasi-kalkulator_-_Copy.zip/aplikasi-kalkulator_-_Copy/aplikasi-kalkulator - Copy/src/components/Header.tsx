export default function Header() {
  return (
    <>
      <div className="header">
        <h2 className="header-title">CALCULATOR</h2>
        <p></p>
      </div>
    </>
  );
}
