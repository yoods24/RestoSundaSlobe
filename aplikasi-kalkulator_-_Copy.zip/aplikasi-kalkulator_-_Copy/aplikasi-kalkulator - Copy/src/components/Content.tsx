import { useState } from "react";
export default function Content(menu) {
  let [count, setCount] = useState(0);
  let [total, setTotal] = useState(0);

  function plusOne() {
    setCount(count + 1);
    setTotal(total + menu.price);
    return;
  }
  function subtractOne() {
    setCount(count - 1);
    setTotal(total - menu.price);
    return;
  }
  return (
    <>
      <div className="menu-grid">
        <div className="img-menu">
          {" "}
          <img src={menu.url} alt="" />
        </div>
        <div className="about-menu">
          <h4>
            {menu.name}
            <span>
              <i className="fa fa-star" aria-hidden="true">
                (38)
              </i>
            </span>
          </h4>
          <p>Pork, fried rice</p>
          <h5>harga : {menu.price}</h5>
        </div>
        <div className="arrowdown">
          <p>Jumlah : {count}</p>
          <p>total : {total}</p>
          <button onClick={subtractOne} className="button-30" role="button">
            -
          </button>
          <button onClick={plusOne} className="button-30" role="button">
            +
          </button>
        </div>
      </div>
    </>
  );
}
