export default {
  data: [
    {
      key: 1,
      nim: "21120121120005",
      nama: "Vane Karenina",
      img: "/public/vane.png",
    },
    {
      key: 2,
      nim: "21120121140117",
      nama: "Jonathan Cleiment",
      img: "/public/jonathan.png",
    },
    {
      key: 3,
      nim: "21120121130061",
      nama: "M. Alfito Priananda",
      img: "/public/fito.png",
    },
    {
      key: 4,
      nim: "21120121130046",
      nama: "Ratna Goeng Permadi",
      img: "/public/ratna.png",
    },
    {
      key: 5,
      nim: "21120121140126",
      nama: "Radithya Fawwaz",
      img: "/public/radit.png",
    },
    {
      key: 6,
      nim: "21120121140088",
      nama: "Yuda Nadhika",
      img: "/public/yuda.png",
    },
  ],
};
